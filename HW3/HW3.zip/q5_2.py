# As obtained in previous section
s_inf = 0.10953309002690662
n_case = 2816
n_tot = n_case / (1-s_inf)
print("N_tot = {nt}".format(nt=n_tot))
